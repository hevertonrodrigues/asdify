---
name: Behavior regression
about: Report a case where the skill loses meaning or fails to clarify
labels: bug
---

## User goal

## Original input (anonymized)

## Actual output

## Expected output

## Facts, qualifiers, or constraints affected

## Host, model, mode, and date

Please remove secrets, personally identifiable information, and proprietary text before posting.
