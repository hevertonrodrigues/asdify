# Changelog

## Unreleased (2026-10-08)

- Initial independent agent skill with `lite`, `full`, and `ultra` modes.
- English/PT-BR usage, preservation guardrails, portable installs, example set, and evaluation framework.
- No benchmark improvement claims have been established yet.
