# Contributing

Thanks for helping people read and verify AI output more easily.

## Best contributions

- Real (anonymized) **before/after** cases with preserved facts, obligations and uncertainty.
- Cases where simplification changes the meaning, especially PT-BR and legal/financial/technical documents.
- Clarifications that make the core skill shorter and more reliable.
- Reproducible, blinded evaluations. Do not report fabricated benchmarks or screenshots without methodology.
- Agent installation guides that you've tested on the stated version.

## Workflow

1. Open an issue for a substantial behavior change and explain the user problem.
2. Edit the **canonical** `skills/clear-communication/SKILL.md` first, unless updating an adapter.
3. Add a minimal adversarial example in `examples/` or `benchmarks/cases.jsonl`.
4. Run `python3 scripts/validate.py` and `python3 -m unittest discover -s tests -v`.
5. Submit a PR with: problem, changed behavior, evidence, possible regressions.

Keep language inclusive and readable. Do not share private documents or secrets. Public examples must be original, licensed appropriately, or short enough to be safely paraphrased.

By contributing, you agree to license your contribution under the project's MIT license. Review [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md) and [SECURITY.md](SECURITY.md).
