# Installation

The canonical skill is `skills/clear-communication/`. Install from a trusted clone of this repository. Review the text before adding always-on instructions to your agent.

## One command (from the repository root)

```bash
bash scripts/install.sh --agent claude --scope user
bash scripts/install.sh --agent codex --scope user
cd /path/to/your-project
bash /path/to/clear-communication/scripts/install.sh --agent cursor --scope project
```

`--force` replaces an existing install. Without it, the script refuses to overwrite. `--scope project` copies into the current working directory; run it in the project that should receive the skill. The script is dependency-free beyond Bash and common POSIX commands. For `--scope user`, installs are per-machine.

## Paths and activation

| Host | User | Project | Activation |
| --- | --- | --- | --- |
| Claude Code | `~/.claude/skills/clear-communication/SKILL.md` | `.claude/skills/clear-communication/SKILL.md` | Skill discovery, or `/clear-communication` where supported |
| Codex | `~/.agents/skills/clear-communication/SKILL.md` | `.agents/skills/clear-communication/SKILL.md` | Skill discovery; invocation syntax depends on client |
| Cursor | Use project installation | `.cursor/rules/clear-communication.mdc` | Project rule (always applied per file rule metadata) |

The Cursor adapter is a **compact rule**, not a full skill copy. For full skill semantics, also install it using Cursor's supported Agent Skills path according to your Cursor version. Instruction-file behavior and names may change by host/version.

## Portable manual install

Copy the entire skill folder (not just `SKILL.md`) into the Agent Skills directory recognized by the host. The package has no runtime scripts or external dependencies.

```bash
# Example: Claude Code per-project
mkdir -p .claude/skills
cp -R /path/to/clear-communication/skills/clear-communication .claude/skills/
```

For agents that do not load skills, copy the compact instructions from [AGENTS.md](AGENTS.md) into the applicable agent rules file (e.g. project `AGENTS.md`, `CLAUDE.md`, or equivalent). Note: project `AGENTS.md` may already exist; **merge** with existing project rules rather than overwriting.

## Modes

Tell the agent `Use clear-communication lite/full/ultra`, or invoke the skill in clients that expose it as a direct command. Mode switching and `off` are semantic instructions; this repository does **not** install a background daemon, event hooks, or global slash-command dispatcher.

## Uninstall

Remove only the installed skill folder/rule shown above. Do not delete a pre-existing folder unless you are sure it was installed by this project.

## Troubleshooting

- **Skill not available?** Verify the path, restart your agent session, and explicitly ask the agent to use `clear-communication`.
- **No change in output?** Request `full` or `ultra`; already-clear text intentionally receives few edits.
- **Facts removed?** That is a bug. Include the source and the incorrect output in an issue, with private data removed.
- **Existing file blocked?** Review differences before rerunning with `--force`.
