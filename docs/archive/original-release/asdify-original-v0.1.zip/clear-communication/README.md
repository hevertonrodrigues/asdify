# Clear Communication

**Less fluff. More signal. No lost meaning.**

A portable **AI agent skill** that turns vague, bloated answers into clear, precise communication. For Claude Code, Codex and other agents that support `SKILL.md`; also usable as a compact `AGENTS.md` rule set.

[Português (Brasil)](README.pt-BR.md) · [Install](INSTALL.md) · [Examples](examples/before-after.md) · [Evaluation](benchmarks/README.md) · [Contributing](CONTRIBUTING.md)

> **Different from “make it shorter.”** A shorter answer is worse when it loses dates, numbers, causality, limitations, or obligations. Clear Communication optimizes for *minimum reader effort with full meaning preserved*.

## Try it in 30 seconds

Clone the project and install locally:

```bash
git clone https://github.com/YOUR-ORG/clear-communication.git
cd clear-communication
bash scripts/install.sh --agent claude --scope user
```

Replace `YOUR-ORG` with the account that publishes the repository. Or copy [`skills/clear-communication/`](skills/clear-communication/) into your agent's skills directory. The installation script does not overwrite existing installations unless you pass `--force`.

Use it in your agent with a prompt like:

```text
Use clear-communication full. Rewrite this status update for an executive.
Preserve every date, amount, risk and uncertainty: ...
```

The host may invoke the skill automatically when relevant. Some hosts support direct skill commands; exact syntax varies.

## Before / after

**Before**

> In light of the evolving landscape, our organization is currently evaluating a number of opportunities that could potentially drive enhanced operational efficiencies in the foreseeable future.

**After**

> We are evaluating opportunities to improve operational efficiency.

**Why:** clear actor and action, without inventing decisions or results.

**Precision matters**

Before: `Revenue increased 12% year over year in Brazil, excluding refunds. The result is preliminary.`

After: `Preliminary revenue in Brazil rose 12% year over year, excluding refunds.`

Not acceptable: `Revenue grew 12%.` (loses region, period, exclusion, and uncertainty)

See more [English and Portuguese examples](examples/before-after.md).

## What it does

- **Answer-first writing.** Lead with what the reader needs to know.
- **Controlled ambiguity.** Prefer consistent words and explicit qualifiers.
- **Meaning-first compression.** Remove filler without removing facts.
- **Calibrated claims.** Separate facts, assumptions, and recommendations.
- **Flexible intensity.** `lite`, `full`, `ultra`, `off`.
- **Multilingual output.** Apply principles in the user's language, including English and Brazilian Portuguese.

### Three modes

| Mode | Best for | Behavior |
| --- | --- | --- |
| `lite` | Editing existing copy | Minimal, local changes; keeps original structure |
| `full` (default) | Daily work | Clear, answer-first restructuring if useful |
| `ultra` | Dense reports and bloated drafts | Challenge unnecessary sections; compress while retaining every material condition |

`ultra` never bypasses factual integrity or safety-critical content.

## How it works

```text
Understand reader + goal
        ↓
Mark facts and constraints that cannot change
        ↓
Apply minimum sufficient edit
        ↓
Check clarity, fidelity and uncertainty
        ↓
Deliver the response in the reader's language
```

The primary skill lives at [`skills/clear-communication/SKILL.md`](skills/clear-communication/SKILL.md). [`AGENTS.md`](AGENTS.md) is the compact always-on alternative. Detailed edge cases and the quality rubric are loaded only when helpful.

## Installation

| Host | Suggested installation |
| --- | --- |
| Claude Code | `bash scripts/install.sh --agent claude --scope user` |
| Codex | `bash scripts/install.sh --agent codex --scope user` |
| Cursor | From your target project: `bash /path/to/clear-communication/scripts/install.sh --agent cursor --scope project` |
| Other Agent Skills hosts | Copy the `skills/clear-communication/` folder to its supported skills path |
| General coding agent | Add compact rules from `AGENTS.md` to the agent's instruction file |

See [INSTALL.md](INSTALL.md) for precise paths, safe reinstall, and differences between auto-invocation and persistent instructions.

## Benchmarks: earn the numbers

No unsupported speed, token, or quality improvements are claimed. The repository includes a [reproducible evaluation protocol](benchmarks/README.md), multilingual fixtures, and a human-scoring rubric. Compare identical prompts with and without the skill. **A candidate that changes a material fact fails, regardless of brevity.** Contributions with blinded, reproducible evidence are welcome.

## Why this exists

As agents generate more text, the human bottleneck becomes reading, checking, and deciding. The goal is communication that people can verify quickly. This project is not an ASD-STE100 implementation. It draws inspiration from the general idea of controlled language, among other sources.

### Inspiration and independence

- [Ponytail](https://github.com/DietrichGebert/ponytail), for the minimal-sufficient-solution approach and an agent-friendly repo experience. Our rules and materials are independently authored and target **communication**, not coding.
- [Agent Skills specification](https://agentskills.io/specification), for the portable `SKILL.md` package format.
- [ASD-STE100 / Simplified Technical English](https://www.asd-ste100.org/), for the public concept of reduced ambiguity. **This is not compliant with, certified by, affiliated with, or endorsed by ASD/ASD-STE100.** Its official dictionary and specification text are not bundled.

## Contribute

Have a sentence the model always ruins? Open a [counterexample](CONTRIBUTING.md). Evidence-backed improvements to preservation rules, languages, and evaluation cases are especially welcome.

MIT license. See [LICENSE](LICENSE). See the [launch checklist](docs/LAUNCH.md) before publishing under a real GitHub owner.
