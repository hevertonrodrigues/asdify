# Clear Communication

**Less fluff. More signal. No lost meaning.**

Uma **Skill open source para agentes de IA** que melhora clareza, precisão e objetividade em respostas, relatórios, análises e documentos. Funciona com agentes que usam `SKILL.md` e também pode ser adaptada como instrução permanente via `AGENTS.md`.

[English](README.md) · [Instalação](INSTALL.md) · [Exemplos](examples/before-after.md) · [Avaliação](benchmarks/README.md) · [Contribuir](CONTRIBUTING.md)

**Não significa simplesmente escrever menos.** Uma resposta curta é pior quando perde números, datas, exceções, incertezas ou obrigações. A meta é reduzir o esforço de leitura **sem perder significado**.

## Instale localmente

```bash
git clone https://github.com/YOUR-ORG/clear-communication.git
cd clear-communication
bash scripts/install.sh --agent claude --scope user
```

Troque `YOUR-ORG` pelo usuário ou organização que publicar o projeto. O script não sobrescreve uma instalação existente sem `--force`.

Experimente:

```text
Use clear-communication full. Reescreva este relatório para a diretoria.
Mantenha todos os números, prazos, riscos e limitações: ...
```

## Três modos

| Modo | Comportamento |
| --- | --- |
| `lite` | Ajustes mínimos, preservando estrutura e tom |
| `full` | Padrão: organiza a resposta e remove redundância |
| `ultra` | Questiona seções supérfluas e comprime mais, mas não remove informações essenciais |

O projeto utiliza uma sequência simples: entender o leitor e o objetivo, identificar o que não pode mudar, fazer a menor intervenção suficiente e verificar fidelidade, clareza e incertezas.

## Diferença em relação ao Ponytail

O [Ponytail](https://github.com/DietrichGebert/ponytail) ajuda agentes a escrever o mínimo de código necessário. O Clear Communication aplica uma filosofia semelhante à **forma como agentes explicam, analisam e escrevem**. São ferramentas complementares.

## Avaliação honesta

Não divulgamos métricas de melhoria sem experimentos. Há casos em português e inglês, uma metodologia de testes comparativos e critérios de aprovação em [benchmarks/](benchmarks/). Uma alteração que perde informação relevante é reprovada mesmo que seja mais curta.

## Aviso sobre ASD-STE100

A Skill se inspira em conceitos gerais de linguagem controlada e baixa ambiguidade, associados ao ASD-STE100, mas **não implementa o padrão oficial, não usa seu dicionário controlado e não tem certificação, conformidade ou endosso da ASD**. A adaptação ao português não é Simplified Technical English oficial.

Consulte [INSTALL.md](INSTALL.md), [CONTRIBUTING.md](CONTRIBUTING.md) e [docs/LAUNCH.md](docs/LAUNCH.md). Licença MIT.
