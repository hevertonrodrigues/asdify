# Evaluation: quality before compression

The project does **not** claim validated gains yet. This folder provides a dataset and protocol for a real A/B test.

## Protocol

1. **Freeze** the model/version, temperature, tools, sampling budget, system context, and input prompt for each case. Record them in the results folder.
2. Run the same cases in two independent sessions: **baseline** without the skill and **treatment** with the canonical `SKILL.md` fully available. Rotate order and repeat if randomness matters.
3. Capture the **raw output** for every run. An independent preparer anonymizes condition labels as A/B and randomizes order before rating.
4. Have at least two reviewers independently score both outputs using the [rubric](../skills/clear-communication/references/quality-rubric.md). Resolve major disagreements and report reviewer agreement.
5. Mark **hard failure** if any material fact, number, condition, obligation, safety detail, or citation is invented or lost. A hard failure cannot count as a win.
6. Report fidelity fail rate, median dimension scores, blinded pairwise preferences, and uncertainty across repeated cases. Report tokens and latency as secondary results, not evidence of comprehension.
7. Publish prompts, model details, anonymized outputs, scoring sheets, scripts, run dates and limitations. Do not claim generalization from one model or a handful of examples.

## Dataset

`cases.jsonl` contains original, bilingual scenarios with explicit invariants. They test summarizing, rewriting, legal modality, numerical interpretation, executive updates, and concise replies.

The cases are **test inputs**, not AI-generated outputs. They are not performance evidence.

## Scoring form

Use `benchmarks/ratings-template.csv`: one blinded row for each case × arm × reviewer. Fill integer values 1–5 (meaning_fidelity, clarity, signal_density, structure, calibration, fit_for_purpose), and `hard_fail` (0 or 1). `arm` is A or B; the study organizer must keep the real mapping secret until scoring is complete.

Run:

```bash
python3 scripts/score_ratings.py benchmarks/ratings-template.csv
```

The template deliberately contains **no ratings**. The script refuses to calculate with an unfilled template. For meaningful results, use blinded paired ratings and publish both raw/aggregate outcomes with methodological limits.

## Success criteria for v1 evaluation

- No meaningful increase in hard failures vs baseline; ideally fewer.
- Higher blinded ratings for clarity and signal density **without decreased fidelity**.
- Benefit across at least two models and both English and Portuguese, before claiming broad effectiveness.

These are targets, not achieved results. Please submit replicable runs via PR.
