# Launch playbook (no ranking guarantees)

## Positioning

**Name:** Clear Communication

**GitHub repository:** `clear-communication` (choose a real organization/owner at publication). Confirm the path is available for that account. A generic name is descriptive and searchable but not a unique trademark.

**Repository description (copy/paste):** `AI agent skill for clear, concise, precise responses. Less fluff, more signal, no lost meaning. Claude Code, Codex & Cursor.`

**Suggested topics** (within GitHub's 20-topic limit): `agent-skills`, `ai-agents`, `prompt-engineering`, `plain-language`, `technical-writing`, `writing-assistant`, `claude-code`, `codex`, `cursor`, `llm`, `communication`, `documentation`, `open-source`, `business-writing`, `simplification`.

**Social tagline:** `The best AI answer is the one you understand on the first read.`

## T-minus release

1. Pick maintainer owner/organization, public email or private vulnerability reporting channel, and check repo/name trademark conflicts.
2. Replace `YOUR-ORG` in README files with the public owner. Verify the git clone command.
3. Test on actual current versions of Claude Code, Codex, and Cursor. Mark tested dates in docs. Confirm the Claude marketplace manifest works before advertising plugin commands.
4. Enable GitHub Actions, Issues, Discussions (if you can moderate), and private vulnerability reporting where available.
5. Publish a tagged `v0.1.0` after validation. Include examples, compatibility and limitations in release notes.
6. Add the short description and topics in GitHub settings. Use an original social preview image (not a copied Ponytail graphic), ideally a single before/after with a distinct brand.

## First 30 days

**Week 1:** publish one real, reproducible before/after demo in EN and PT-BR; release installation notes and collect issue reports. Demonstrate number/uncertainty preservation, not just shorter text.

**Week 2:** run and publish a blinded A/B evaluation with model version, cases, and counterexamples. Update rules only after analyzing failure cases.

**Week 3:** test alternative model/agent hosts; accept integration PRs only with installation evidence; share substantive demos in relevant GitHub/Agent Skills communities, following each community's posting rules.

**Week 4:** package the first stable release based on the public regression suite. Publish failures and the fixes as openly as successes.

## Distribution, responsibly

- Submit to Agent Skills/community directories that accept open submissions and where the package matches requirements. Follow directory rules; do not spam.
- Publish practical technical posts, including preservation failures and how they were resolved. Link to the source and methodology.
- Keep README search terms accurate and natural; avoid keyword stuffing or fake star/review campaigns.
- Encourage contributions and external reproduction rather than incentivized stars.

## Differentiation vs Ponytail

Ponytail minimizes implementation complexity in code. Clear Communication minimizes reader effort across AI writing tasks. Share its philosophy of minimum sufficient work and reproducible evidence, but use independent examples, copy, rules and visual identity.

## Success metrics to monitor

- Monthly unique external contributors, issue resolution time, install instructions tested, and documented compatibility.
- Reproducible quality/fidelity gains and hard-failure rate on held-out tasks.
- Repository traffic, stars, forks and referrals as interest signals, **not** proof of quality.

No listing, search position or virality is guaranteed.
