#!/usr/bin/env python3
"""Aggregate blinded human ratings. Does not grade with an LLM or infer causality."""
import csv
import statistics
import sys
from collections import defaultdict

DIMENSIONS = ("meaning_fidelity", "clarity", "signal_density", "structure", "calibration", "fit_for_purpose")


def score(filename):
    with open(filename, newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError("No ratings supplied. Fill a copy of benchmarks/ratings-template.csv first.")
    groups = defaultdict(list)
    pairs = defaultdict(set)
    for n, row in enumerate(rows, start=2):
        arm = row.get("arm", "").strip().upper()
        if arm not in ("A", "B"):
            raise ValueError(f"Row {n}: arm must be A or B")
        key = (row.get("reviewer", "").strip(), row.get("case_id", "").strip())
        if not all(key):
            raise ValueError(f"Row {n}: reviewer and case_id required")
        if arm in pairs[key]:
            raise ValueError(f"Row {n}: duplicate arm for same reviewer and case")
        pairs[key].add(arm)
        if row.get("hard_fail") not in ("0", "1"):
            raise ValueError(f"Row {n}: hard_fail must be 0 or 1")
        for dim in DIMENSIONS:
            try:
                score_value = int(row.get(dim, ""))
            except ValueError as exc:
                raise ValueError(f"Row {n}: {dim} must be an integer from 1 to 5") from exc
            if not 1 <= score_value <= 5:
                raise ValueError(f"Row {n}: {dim} must be 1–5")
        groups[arm].append(row)
    for key, arms in pairs.items():
        if arms != {"A", "B"}:
            raise ValueError(f"Unpaired evaluation {key}: both A and B required")

    for arm in ("A", "B"):
        group = groups[arm]
        print(f"Arm {arm}: {len(group)} blind ratings, hard failures: {sum(r['hard_fail'] == '1' for r in group)}")
        for dim in DIMENSIONS:
            vals = [int(r[dim]) for r in group]
            print(f"  {dim}: median {statistics.median(vals):g}, mean {statistics.mean(vals):.2f}")
    print("Conditions stay blinded here; unblind only after grading is complete.")


if __name__ == "__main__":
    try:
        if len(sys.argv) != 2:
            raise ValueError("Usage: python3 scripts/score_ratings.py path/to/ratings.csv")
        score(sys.argv[1])
    except (ValueError, OSError) as error:
        print(f"Error: {error}", file=sys.stderr)
        sys.exit(1)
