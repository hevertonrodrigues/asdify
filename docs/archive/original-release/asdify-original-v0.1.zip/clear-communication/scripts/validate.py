#!/usr/bin/env python3
"""Check core skill, relative links, and benchmark fixture syntax without dependencies."""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "skills/clear-communication/SKILL.md"
LINK = re.compile(r"\[[^\]]+\]\(([^)]+)\)")


def validate_skill():
    content = SKILL.read_text(encoding="utf-8")
    if not content.startswith("---\n"):
        raise ValueError("SKILL.md must start with YAML frontmatter")
    end = content.find("\n---\n", 4)
    if end == -1:
        raise ValueError("Missing end of YAML frontmatter")
    header = content[4:end]
    name = re.search(r"^name:\s*(.+)$", header, re.M)
    desc = re.search(r"^description:\s*>\s*\n((?:[ \t]+[^\n]+\n?)+)", header, re.M)
    if not name or name.group(1).strip() != SKILL.parent.name:
        raise ValueError("Skill name must match folder")
    if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name.group(1).strip()):
        raise ValueError("Invalid skill name")
    if not desc or not (1 <= len(" ".join(desc.group(1).split())) <= 1024):
        raise ValueError("Missing or overlong description")
    if len(content.splitlines()) > 500:
        raise ValueError("SKILL.md should stay below 500 lines")
    for token in ("lite", "full", "ultra", "meaning", "uncertainty", "ASD-STE100"):
        if token not in content:
            raise ValueError(f"Missing required principle {token}")


def validate_links():
    errors = []
    for path in ROOT.rglob("*.md"):
        if any(part.startswith(".") and part != ".github" for part in path.relative_to(ROOT).parts):
            continue
        content = path.read_text(encoding="utf-8")
        for url in LINK.findall(content):
            url = url.strip().split()[0].split("#")[0]
            if not url or url.startswith(("https://", "http://", "mailto:", "/")):
                continue
            if not (path.parent / url).exists():
                errors.append(f"{path.relative_to(ROOT)}: missing {url}")
    if errors:
        raise ValueError("Broken relative links:\n" + "\n".join(errors))


def validate_cases():
    path = ROOT / "benchmarks/cases.jsonl"
    ids = set()
    for index, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        item = json.loads(line)
        if not all(item.get(k) for k in ("id", "lang", "task", "invariants", "risk")):
            raise ValueError(f"case {index}: missing fields")
        if item["id"] in ids:
            raise ValueError(f"case {index}: duplicate id")
        if item["lang"] not in ("en", "pt-BR") or not isinstance(item["invariants"], list):
            raise ValueError(f"case {index}: invalid language or invariants")
        ids.add(item["id"])
    if len(ids) < 6:
        raise ValueError("Need >= 6 diverse evaluation cases")
    return len(ids)


def main():
    validate_skill()
    validate_links()
    count = validate_cases()
    print(f"Validation OK: core skill, relative links, and {count} bilingual cases")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        print(f"Validation failed: {exc}", file=sys.stderr)
        sys.exit(1)
