import csv
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ProjectTests(unittest.TestCase):
    def test_structure_and_examples(self):
        result = subprocess.run(["python3", str(ROOT / "scripts/validate.py")], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Validation OK", result.stdout)

    def test_installer_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as work:
            args = ["bash", str(ROOT / "scripts/install.sh"), "--agent", "claude", "--scope", "project"]
            first = subprocess.run(args, cwd=work, capture_output=True, text=True)
            self.assertEqual(first.returncode, 0, first.stderr)
            installed = Path(work) / ".claude/skills/clear-communication/SKILL.md"
            self.assertTrue(installed.exists())
            again = subprocess.run(args, cwd=work, capture_output=True, text=True)
            self.assertNotEqual(again.returncode, 0)
            self.assertIn("Refusing", again.stderr)
            forced = subprocess.run(args + ["--force"], cwd=work, capture_output=True, text=True)
            self.assertEqual(forced.returncode, 0, forced.stderr)

    def test_cursor_adapter(self):
        with tempfile.TemporaryDirectory() as work:
            proc = subprocess.run(["bash", str(ROOT / "scripts/install.sh"), "--agent", "cursor", "--scope", "project"], cwd=work, capture_output=True, text=True)
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertTrue((Path(work) / ".cursor/rules/clear-communication.mdc").exists())

    def test_empty_scores_do_not_produce_claims(self):
        proc = subprocess.run(["python3", str(ROOT / "scripts/score_ratings.py"), str(ROOT / "benchmarks/ratings-template.csv")], capture_output=True, text=True)
        self.assertNotEqual(proc.returncode, 0)
        self.assertIn("No ratings", proc.stderr)

    def test_scoring_paired_rows(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "test.csv"
            header = ["reviewer", "case_id", "arm", "meaning_fidelity", "clarity", "signal_density", "structure", "calibration", "fit_for_purpose", "hard_fail", "notes"]
            with path.open("w", newline="", encoding="utf-8") as fh:
                writer = csv.writer(fh); writer.writerow(header)
                for arm in ("A", "B"):
                    writer.writerow(["reviewer1", "case1", arm, 5, 4, 4, 5, 5, 5, 0, ""])
            proc = subprocess.run(["python3", str(ROOT / "scripts/score_ratings.py"), str(path)], capture_output=True, text=True)
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertIn("Arm A:", proc.stdout)
            self.assertIn("Arm B:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
